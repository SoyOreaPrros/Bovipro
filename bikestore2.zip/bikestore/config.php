<?php
$host = "localhost";
$user = "bikestore";
$pass = "123456";
$db   = "bikestore";

$mysqli = new mysqli($host, $user, $pass, $db);

if ($mysqli->connect_errno) {
    die("Error de conexión: " . $mysqli->connect_error);
}

$mysqli->set_charset("utf8");
?>
