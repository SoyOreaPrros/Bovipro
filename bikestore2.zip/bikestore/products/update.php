<?php
require "../config.php";

$id = $_GET['id'];

$brands = $mysqli->query("SELECT * FROM brands");
$cats   = $mysqli->query("SELECT * FROM categories");

$sql = "SELECT * FROM products WHERE product_id=$id";
$res = $mysqli->query($sql);
$data = $res->fetch_assoc();

if ($_POST) {
    $name = $_POST['product_name'];
    $brand = $_POST['brand_id'];
    $cat = $_POST['category_id'];
    $year = $_POST['model_year'];
    $price = $_POST['list_price'];

    $sql = "UPDATE products SET
            product_name='$name',
            brand_id=$brand,
            category_id=$cat,
            model_year=$year,
            list_price=$price
            WHERE product_id=$id";

    $mysqli->query($sql);
    header("Location: read.php");
}
?>
<!DOCTYPE html>
<html>
<body>
<h1>Editar producto</h1>

<form method="POST">
    Nombre: <input name="product_name" value="<?= $data['product_name'] ?>"><br><br>

    Marca:
    <select name="brand_id">
        <?php
        while($b=$brands->fetch_assoc()) {
            $sel = ($b['brand_id']==$data['brand_id']) ? "selected" : "";
            echo "<option value='{$b['brand_id']}' $sel>{$b['brand_name']}</option>";
        }
        ?>
    </select><br><br>

    Categoría:
    <select name="category_id">
        <?php
        while($c=$cats->fetch_assoc()) {
            $sel = ($c['category_id']==$data['category_id']) ? "selected" : "";
            echo "<option value='{$c['category_id']}' $sel>{$c['category_name']}</option>";
        }
        ?>
    </select><br><br>

    Año modelo: <input name="model_year" type="number" value="<?= $data['model_year'] ?>"><br><br>
    Precio: <input name="list_price" type="number" step="0.01" value="<?= $data['list_price'] ?>"><br><br>

    <button>Actualizar</button>
</form>

<a href="read.php">⬅ Volver</a>
</body>
</html>
