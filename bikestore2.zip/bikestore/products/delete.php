<?php
require "../config.php";

$id = $_GET['id'];
$sql = "DELETE FROM products WHERE product_id=$id";
$mysqli->query($sql);

header("Location: read.php");
