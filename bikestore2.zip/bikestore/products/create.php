<?php
require "../config.php";

$brands = $mysqli->query("SELECT * FROM brands");
$cats   = $mysqli->query("SELECT * FROM categories");

if ($_POST) {
    $name = $_POST['product_name'];
    $brand = $_POST['brand_id'];
    $cat = $_POST['category_id'];
    $year = $_POST['model_year'];
    $price = $_POST['list_price'];

    $sql = "INSERT INTO products (product_name, brand_id, category_id, model_year, list_price)
            VALUES ('$name', $brand, $cat, $year, $price)";
    $mysqli->query($sql);

    header("Location: read.php");
}
?>
<!DOCTYPE html>
<html>
<body>
<h1>Nuevo producto</h1>

<form method="POST">
    Nombre: <input name="product_name"><br><br>

    Marca:
    <select name="brand_id">
        <?php while($b=$brands->fetch_assoc()) echo "<option value='{$b['brand_id']}'>{$b['brand_name']}</option>"; ?>
    </select><br><br>

    Categoría:
    <select name="category_id">
        <?php while($c=$cats->fetch_assoc()) echo "<option value='{$c['category_id']}'>{$c['category_name']}</option>"; ?>
    </select><br><br>

    Año modelo: <input name="model_year" type="number"><br><br>
    Precio: <input name="list_price" type="number" step="0.01"><br><br>

    <button>Guardar</button>
</form>

<a href="read.php">⬅ Volver</a>
</body>
</html>
