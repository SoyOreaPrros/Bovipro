<?php
require "../config.php";
?>
<!DOCTYPE html>
<html>
<body>
<h1>Products</h1>
<a href="create.php">➕ Nuevo producto</a>
<a href="../index.php">⬅ Volver</a>

<table border="1" cellpadding="6">
<tr>
<th>ID</th><th>Producto</th><th>Marca</th><th>Categoría</th><th>Año</th><th>Precio</th><th>Acciones</th>
</tr>

<?php
$sql = "SELECT p.*, b.brand_name, c.category_name
        FROM products p
        JOIN brands b ON p.brand_id=b.brand_id
        JOIN categories c ON p.category_id=c.category_id
        ORDER BY p.product_name";

$res = $mysqli->query($sql);

while ($row = $res->fetch_assoc()) {
    echo "<tr>
            <td>{$row['product_id']}</td>
            <td>{$row['product_name']}</td>
            <td>{$row['brand_name']}</td>
            <td>{$row['category_name']}</td>
            <td>{$row['model_year']}</td>
            <td>{$row['list_price']}</td>
            <td>
                <a href='edit.php?id={$row['product_id']}'>Editar</a> |
                <a href='delete.php?id={$row['product_id']}'>Eliminar</a>
            </td>
          </tr>";
}
?>
</table>
</body>
</html>
