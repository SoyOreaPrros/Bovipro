<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>BikeStore – Panel de consulta</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; }
        header { background: #222; color: #fff; padding: 10px 20px; }
        nav { background: #444; padding: 10px; }
        nav a { color: #fff; margin-right: 15px; text-decoration: none; }
        nav a:hover { text-decoration: underline; }
        main { padding: 20px; }
        table { border-collapse: collapse; width: 100%; margin-top: 10px; }
        th, td { border: 1px solid #ccc; padding: 6px 8px; font-size: 14px; }
        th { background: #eee; }
        h1 { margin-top: 0; }
        .small { font-size: 12px; color: #666; }
    </style>
</head>
<body>
	<header>
		<h1>BikeStore – Pedidos</h1>
	</header>
	<?php
		require_once "../config.php";
        echo '<h2><a href="../index.php?view=home">Inicio</a></h2>';
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        echo "<h2>Detalle del pedido #{$id}</h2>";

        // Encabezado del pedido
        $sqlHead = "SELECT o.order_id, o.order_date, o.required_date, o.shipped_date,
                           c.first_name AS c_first, c.last_name AS c_last,
                           s.store_name,
                           st.first_name AS st_first, st.last_name AS st_last
                    FROM orders o
                    JOIN customers c ON o.customer_id = c.customer_id
                    JOIN stores s ON o.store_id = s.store_id
                    JOIN staffs st ON o.staff_id = st.staff_id
                    WHERE o.order_id = {$id}";
        if ($resH = $mysqli->query($sqlHead)) {
            if ($row = $resH->fetch_assoc()) {
                echo "<p><strong>Cliente:</strong> {$row['c_first']} {$row['c_last']}<br>";
                echo "<strong>Tienda:</strong> {$row['store_name']}<br>";
                echo "<strong>Empleado:</strong> {$row['st_first']} {$row['st_last']}<br>";
                echo "<strong>Fecha pedido:</strong> {$row['order_date']}<br>";
                echo "<strong>Requerido:</strong> {$row['required_date']}<br>";
                echo "<strong>Enviado:</strong> {$row['shipped_date']}</p>";
            } else {
                echo "<p>Pedido no encontrado.</p>";
            }
            $resH->free();
        }

        // Detalle de artículos
        $sqlDet = "SELECT oi.item_id, p.product_name, oi.quantity, oi.list_price, oi.discount,
                          (oi.quantity * oi.list_price * (1 - oi.discount)) AS total_linea
                   FROM order_items oi
                   JOIN products p ON oi.product_id = p.product_id
                   WHERE oi.order_id = {$id}";
        if ($resD = $mysqli->query($sqlDet)) {
            echo "<table>";
            echo "<tr><th>Item</th><th>Producto</th><th>Cantidad</th><th>Precio lista</th><th>Descuento</th><th>Total línea</th></tr>";
            $totalPedido = 0;
            while ($row = $resD->fetch_assoc()) {
                $totalPedido += $row['total_linea'];
                echo "<tr>";
                echo "<td>{$row['item_id']}</td>";
                echo "<td>{$row['product_name']}</td>";
                echo "<td>{$row['quantity']}</td>";
                echo "<td>$" . number_format($row['list_price'], 2) . "</td>";
                echo "<td>" . ($row['discount'] * 100) . "%</td>";
                echo "<td>$" . number_format($row['total_linea'], 2) . "</td>";
                echo "</tr>";
            }
            echo "<tr><th colspan='5' style='text-align:right;'>Total del pedido:</th>";
            echo "<th>$" . number_format($totalPedido, 2) . "</th></tr>";
            echo "</table>";
            $resD->free();
        } else {
            echo "Error en la consulta.";
        }

        echo "<p><a href='orders.php'>&laquo; Volver a pedidos</a></p>";
	?>
</body>
</html>			