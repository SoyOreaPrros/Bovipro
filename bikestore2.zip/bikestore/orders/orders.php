<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>BikeStore – Panel de consulta</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; }
        header { background: #222; color: #fff; padding: 10px 20px; }
        nav { background: #444; padding: 10px; }
        nav a { color: #fff; margin-right: 15px; text-decoration: none; }
        nav a:hover { text-decoration: underline; }
        main { padding: 20px; }
        table { border-collapse: collapse; width: 100%; margin-top: 10px; }
        th, td { border: 1px solid #ccc; padding: 6px 8px; font-size: 14px; }
        th { background: #eee; }
        h1 { margin-top: 0; }
        .small { font-size: 12px; color: #666; }
    </style>
</head>
<body>
	<header>
		<h1>BikeStore – Pedidos</h1>
	</header>
	<?php
		require_once "../config.php";
        echo '<h2><a href="../index.php?view=home">Inicio</a></h2>';
        echo "<p class='small'>Haz clic en el ID del pedido para ver el detalle.</p>";
        $sql = "SELECT o.order_id, o.order_date, o.required_date, o.shipped_date,
                       c.first_name AS c_first, c.last_name AS c_last,
                       s.store_name,
                       st.first_name AS st_first, st.last_name AS st_last
                FROM orders o
                JOIN customers c ON o.customer_id = c.customer_id
                JOIN stores s ON o.store_id = s.store_id
                JOIN staffs st ON o.staff_id = st.staff_id
                ORDER BY o.order_date DESC";
        if ($res = $mysqli->query($sql)) {
            echo "<table>";
            echo "<tr><th>ID</th><th>Fecha pedido</th><th>Cliente</th><th>Tienda</th><th>Empleado</th><th>Requerido</th><th>Enviado</th></tr>";
            while ($row = $res->fetch_assoc()) {
                $id = $row['order_id'];
                echo "<tr>";
                echo "<td><a href='order_detail.php?id={$id}'>{$id}</a></td>";
                echo "<td>{$row['order_date']}</td>";
                echo "<td>{$row['c_first']} {$row['c_last']}</td>";
                echo "<td>{$row['store_name']}</td>";
                echo "<td>{$row['st_first']} {$row['st_last']}</td>";
                echo "<td>{$row['required_date']}</td>";
                echo "<td>{$row['shipped_date']}</td>";
                echo "</tr>";
            }
            echo "</table>";
            $res->free();
        } else {
            echo "Error en la consulta.";
        }
	?>
</body>
</html>			