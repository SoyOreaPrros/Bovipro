<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>BikeStore – Panel de consulta</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; }
        header { background: #222; color: #fff; padding: 10px 20px; }
        nav { background: #444; padding: 10px; }
        nav a { color: #fff; margin-right: 15px; text-decoration: none; }
        nav a:hover { text-decoration: underline; }
        main { padding: 20px; }
        table { border-collapse: collapse; width: 100%; margin-top: 10px; }
        th, td { border: 1px solid #ccc; padding: 6px 8px; font-size: 14px; }
        th { background: #eee; }
        h1 { margin-top: 0; }
        .small { font-size: 12px; color: #666; }
    </style>
</head>
<body>
	<header>
		<h1>BikeStore – Catálogo de productos</h1>
	</header>
	<?php
		require_once "../config.php";
        echo '<h2><a href="../index.php?view=home">Volver</a></h2>';
        $sql = "SELECT p.product_id, p.product_name, b.brand_name, c.category_name,
                       p.model_year, p.list_price
                FROM products p
                JOIN brands b ON p.brand_id = b.brand_id
                JOIN categories c ON p.category_id = c.category_id
                ORDER BY p.product_name";
        if ($res = $mysqli->query($sql)) {
            echo "<table>";
            echo "<tr><th>ID</th><th>Producto</th><th>Marca</th><th>Categoría</th><th>Año</th><th>Precio lista</th></tr>";
            while ($row = $res->fetch_assoc()) {
                echo "<tr>";
                echo "<td>{$row['product_id']}</td>";
                echo "<td>{$row['product_name']}</td>";
                echo "<td>{$row['brand_name']}</td>";
                echo "<td>{$row['category_name']}</td>";
                echo "<td>{$row['model_year']}</td>";
                echo "<td>$" . number_format($row['list_price'], 2) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
            $res->free();
        } else {
            echo "Error en la consulta.";
        }
	?>
</body>
</html>