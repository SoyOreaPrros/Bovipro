<?php
require_once "config.php";

$view = isset($_GET['view']) ? $_GET['view'] : 'home';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>BikeStore – Panel de consulta</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; }
        header { background: #222; color: #fff; padding: 10px 20px; }
        nav { background: #444; padding: 10px; }
        nav a { color: #fff; margin-right: 15px; text-decoration: none; }
        nav a:hover { text-decoration: underline; }
        main { padding: 20px; }
        table { border-collapse: collapse; width: 100%; margin-top: 10px; }
        th, td { border: 1px solid #ccc; padding: 6px 8px; font-size: 14px; }
        th { background: #eee; }
        h1 { margin-top: 0; }
        .small { font-size: 12px; color: #666; }
    </style>
</head>
<body>
<header>
    <h1>BikeStore – Panel de consulta</h1>
</header>

<nav>
    <a href="index.php?view=home">Inicio</a>
    <a href="customers/customers.php">Clientes</a>
    <a href="products/products.php">Productos</a>
    <a href="stores/stores.php">Tiendas</a>
    <a href="orders/orders.php">Pedidos</a>
</nav>

<main>
        <h2>Bienvenida/o</h2>
        <p>Este panel permite visualizar la información de la base de datos <strong>BikeStore</strong>:</p>
        <ul>
                <li>Lista de clientes</li>
                <li>Catálogo de productos (con marca y categoría)</li>
                <li>Tiendas</li>
                <li>Pedidos y su detalle</li>
        </ul>
        <p class='small'>Puedes usar esta interfaz como base para prácticas de lectura, modificación y creación de registros.</p>
</main>
</body>
</html>
