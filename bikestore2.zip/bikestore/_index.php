<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>BikeStore – CRUD</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        a { display: block; margin: 10px 0; font-size: 18px; }
    </style>
</head>
<body>
<h1>BikeStore – CRUD</h1>

<a href="stores/list.php">Administrar Stores</a>
<a href="customers/list.php">Administrar Customers</a>
<a href="products/read.php">Administrar Products</a>

</body>
</html>
