<?php
require_once "config.php";

$view = isset($_GET['view']) ? $_GET['view'] : 'home';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>BikeStore – Panel de consulta</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; }
        header { background: #222; color: #fff; padding: 10px 20px; }
        nav { background: #444; padding: 10px; }
        nav a { color: #fff; margin-right: 15px; text-decoration: none; }
        nav a:hover { text-decoration: underline; }
        main { padding: 20px; }
        table { border-collapse: collapse; width: 100%; margin-top: 10px; }
        th, td { border: 1px solid #ccc; padding: 6px 8px; font-size: 14px; }
        th { background: #eee; }
        h1 { margin-top: 0; }
        .small { font-size: 12px; color: #666; }
    </style>
</head>
<body>
<header>
    <h1>BikeStore – Panel de consulta</h1>
</header>

<nav>
    <a href="index.php?view=home">Inicio</a>
    <a href="index.php?view=customers">Clientes</a>
    <a href="index.php?view=products">Productos</a>
    <a href="index.php?view=stores">Tiendas</a>
    <a href="index.php?view=orders">Pedidos</a>
</nav>

<main>
<?php
switch ($view) {

    case 'customers':
        echo "<h2>Clientes</h2>";
        $sql = "SELECT customer_id, first_name, last_name, phone, email, city, state 
                FROM customers
                ORDER BY last_name, first_name";
        if ($res = $mysqli->query($sql)) {
            echo "<table>";
            echo "<tr><th>ID</th><th>Nombre</th><th>Teléfono</th><th>Email</th><th>Ciudad</th><th>Estado</th></tr>";
            while ($row = $res->fetch_assoc()) {
                echo "<tr>";
                echo "<td>{$row['customer_id']}</td>";
                echo "<td>{$row['first_name']} {$row['last_name']}</td>";
                echo "<td>{$row['phone']}</td>";
                echo "<td>{$row['email']}</td>";
                echo "<td>{$row['city']}</td>";
                echo "<td>{$row['state']}</td>";
                echo "</tr>";
            }
            echo "</table>";
            $res->free();
        } else {
            echo "Error en la consulta.";
        }
        break;

    case 'products':
        echo "<h2>Productos</h2>";
        $sql = "SELECT p.product_id, p.product_name, b.brand_name, c.category_name,
                       p.model_year, p.list_price
                FROM products p
                JOIN brands b ON p.brand_id = b.brand_id
                JOIN categories c ON p.category_id = c.category_id
                ORDER BY p.product_name";
        if ($res = $mysqli->query($sql)) {
            echo "<table>";
            echo "<tr><th>ID</th><th>Producto</th><th>Marca</th><th>Categoría</th><th>Año</th><th>Precio lista</th></tr>";
            while ($row = $res->fetch_assoc()) {
                echo "<tr>";
                echo "<td>{$row['product_id']}</td>";
                echo "<td>{$row['product_name']}</td>";
                echo "<td>{$row['brand_name']}</td>";
                echo "<td>{$row['category_name']}</td>";
                echo "<td>{$row['model_year']}</td>";
                echo "<td>$" . number_format($row['list_price'], 2) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
            $res->free();
        } else {
            echo "Error en la consulta.";
        }
        break;

    case 'stores':
        echo "<h2>Tiendas</h2>";
        $sql = "SELECT store_id, store_name, phone, email, city, state 
                FROM stores
                ORDER BY store_name";
        if ($res = $mysqli->query($sql)) {
            echo "<table>";
            echo "<tr><th>ID</th><th>Tienda</th><th>Teléfono</th><th>Email</th><th>Ciudad</th><th>Estado</th></tr>";
            while ($row = $res->fetch_assoc()) {
                echo "<tr>";
                echo "<td>{$row['store_id']}</td>";
                echo "<td>{$row['store_name']}</td>";
                echo "<td>{$row['phone']}</td>";
                echo "<td>{$row['email']}</td>";
                echo "<td>{$row['city']}</td>";
                echo "<td>{$row['state']}</td>";
                echo "</tr>";
            }
            echo "</table>";
            $res->free();
        } else {
            echo "Error en la consulta.";
        }
        break;

    case 'orders':
        echo "<h2>Pedidos</h2>";
        echo "<p class='small'>Haz clic en el ID del pedido para ver el detalle.</p>";
        $sql = "SELECT o.order_id, o.order_date, o.required_date, o.shipped_date,
                       c.first_name AS c_first, c.last_name AS c_last,
                       s.store_name,
                       st.first_name AS st_first, st.last_name AS st_last
                FROM orders o
                JOIN customers c ON o.customer_id = c.customer_id
                JOIN stores s ON o.store_id = s.store_id
                JOIN staffs st ON o.staff_id = st.staff_id
                ORDER BY o.order_date DESC";
        if ($res = $mysqli->query($sql)) {
            echo "<table>";
            echo "<tr><th>ID</th><th>Fecha pedido</th><th>Cliente</th><th>Tienda</th><th>Empleado</th><th>Requerido</th><th>Enviado</th></tr>";
            while ($row = $res->fetch_assoc()) {
                $id = $row['order_id'];
                echo "<tr>";
                echo "<td><a href='index.php?view=order_detail&id={$id}'>{$id}</a></td>";
                echo "<td>{$row['order_date']}</td>";
                echo "<td>{$row['c_first']} {$row['c_last']}</td>";
                echo "<td>{$row['store_name']}</td>";
                echo "<td>{$row['st_first']} {$row['st_last']}</td>";
                echo "<td>{$row['required_date']}</td>";
                echo "<td>{$row['shipped_date']}</td>";
                echo "</tr>";
            }
            echo "</table>";
            $res->free();
        } else {
            echo "Error en la consulta.";
        }
        break;

    case 'order_detail':
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        echo "<h2>Detalle del pedido #{$id}</h2>";

        // Encabezado del pedido
        $sqlHead = "SELECT o.order_id, o.order_date, o.required_date, o.shipped_date,
                           c.first_name AS c_first, c.last_name AS c_last,
                           s.store_name,
                           st.first_name AS st_first, st.last_name AS st_last
                    FROM orders o
                    JOIN customers c ON o.customer_id = c.customer_id
                    JOIN stores s ON o.store_id = s.store_id
                    JOIN staffs st ON o.staff_id = st.staff_id
                    WHERE o.order_id = {$id}";
        if ($resH = $mysqli->query($sqlHead)) {
            if ($row = $resH->fetch_assoc()) {
                echo "<p><strong>Cliente:</strong> {$row['c_first']} {$row['c_last']}<br>";
                echo "<strong>Tienda:</strong> {$row['store_name']}<br>";
                echo "<strong>Empleado:</strong> {$row['st_first']} {$row['st_last']}<br>";
                echo "<strong>Fecha pedido:</strong> {$row['order_date']}<br>";
                echo "<strong>Requerido:</strong> {$row['required_date']}<br>";
                echo "<strong>Enviado:</strong> {$row['shipped_date']}</p>";
            } else {
                echo "<p>Pedido no encontrado.</p>";
            }
            $resH->free();
        }

        // Detalle de artículos
        $sqlDet = "SELECT oi.item_id, p.product_name, oi.quantity, oi.list_price, oi.discount,
                          (oi.quantity * oi.list_price * (1 - oi.discount)) AS total_linea
                   FROM order_items oi
                   JOIN products p ON oi.product_id = p.product_id
                   WHERE oi.order_id = {$id}";
        if ($resD = $mysqli->query($sqlDet)) {
            echo "<table>";
            echo "<tr><th>Item</th><th>Producto</th><th>Cantidad</th><th>Precio lista</th><th>Descuento</th><th>Total línea</th></tr>";
            $totalPedido = 0;
            while ($row = $resD->fetch_assoc()) {
                $totalPedido += $row['total_linea'];
                echo "<tr>";
                echo "<td>{$row['item_id']}</td>";
                echo "<td>{$row['product_name']}</td>";
                echo "<td>{$row['quantity']}</td>";
                echo "<td>$" . number_format($row['list_price'], 2) . "</td>";
                echo "<td>" . ($row['discount'] * 100) . "%</td>";
                echo "<td>$" . number_format($row['total_linea'], 2) . "</td>";
                echo "</tr>";
            }
            echo "<tr><th colspan='5' style='text-align:right;'>Total del pedido:</th>";
            echo "<th>$" . number_format($totalPedido, 2) . "</th></tr>";
            echo "</table>";
            $resD->free();
        } else {
            echo "Error en la consulta.";
        }

        echo "<p><a href='index.php?view=orders'>&laquo; Volver a pedidos</a></p>";
        break;

    case 'home':
    default:
        echo "<h2>Bienvenida/o</h2>";
        echo "<p>Este panel permite visualizar la información de la base de datos <strong>BikeStore</strong>:</p>";
        echo "<ul>
                <li>Lista de clientes</li>
                <li>Catálogo de productos (con marca y categoría)</li>
                <li>Tiendas</li>
                <li>Pedidos y su detalle</li>
              </ul>";
        echo "<p class='small'>Puedes usar esta interfaz como base para prácticas de lectura, modificación y creación de registros.</p>";
        break;
}
?>
</main>
</body>
</html>
