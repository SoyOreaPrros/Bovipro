<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>BikeStore – Panel de consulta</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; }
        header { background: #222; color: #fff; padding: 10px 20px; }
        nav { background: #444; padding: 10px; }
        nav a { color: #fff; margin-right: 15px; text-decoration: none; }
        nav a:hover { text-decoration: underline; }
        main { padding: 20px; }
        table { border-collapse: collapse; width: 100%; margin-top: 10px; }
        th, td { border: 1px solid #ccc; padding: 6px 8px; font-size: 14px; }
        th { background: #eee; }
        h1 { margin-top: 0; }
        .small { font-size: 12px; color: #666; }
    </style>
</head>
<body>
	<header>
		<h1>BikeStore – Catálogo de tiendas</h1>
	</header>
	<?php
		require_once "../config.php";
        echo '<h2><a href="../index.php?view=home">Inicio</a></h2>';
        $sql = "SELECT store_id, store_name, phone, email, city, state 
                FROM stores
                ORDER BY store_name";
        if ($res = $mysqli->query($sql)) {
            echo "<table>";
            echo "<tr><th>ID</th><th>Tienda</th><th>Teléfono</th><th>Email</th><th>Ciudad</th><th>Estado</th></tr>";
            while ($row = $res->fetch_assoc()) {
                echo "<tr>";
                echo "<td>{$row['store_id']}</td>";
                echo "<td>{$row['store_name']}</td>";
                echo "<td>{$row['phone']}</td>";
                echo "<td>{$row['email']}</td>";
                echo "<td>{$row['city']}</td>";
                echo "<td>{$row['state']}</td>";
                echo "</tr>";
            }
            echo "</table>";
            $res->free();
        } else {
            echo "Error en la consulta.";
        }		
	?>
</body>
</html>			